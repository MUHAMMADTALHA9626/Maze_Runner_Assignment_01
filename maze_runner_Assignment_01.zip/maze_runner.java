package SecondClass;

// importing all libraries

import java.util.*;

public class maze_runner {

    // The maze 
    private static char[][] MAZE = {
        {'#', '#', '#', '#', '#', '#', '#'},
        {'#', 'P', '.', '.', '.', '.', '#'},
        {'#', '#', '#', '#', '.', '#', '#'},
        {'#', '.', '.', '.', '.', '.', '#'},
        {'#', '#', '#', '.', '#', '#', '#'},
        {'#', '.', '.', '.', '.', 'E', '#'},
        {'#', '#', '#', '#', '#', '#', '#'}
    };

    // Player's position and game-related variables
    private static int playerX, playerY;
    private static int stepsTaken;
    private static int highScore;
    private static long startTime;
    private static long endTime;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        initializeMaze(); // Find the player's starting position and reset stepsTaken

        while (true) {
            displayMainMenu(); // Display the main menu options
            char option = scanner.next().charAt(0);
            scanner.nextLine(); // Consume the newline character after reading the option

            switch (option) {
                case 'a':
                    playGame(); // Start the game
                    break;
                case 'b':
                    showInstructions(); // Show the game instructions
                    break;
                case 'c':
                    showCredits(); // Show the game credits
                    break;
                case 'd':
                    showHighScore(); // Show the current high score
                    break;
                case 'e':
                    exitGame(); // Exit the game
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    scanner.close();
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("\nMain Menu");
        System.out.println("a. Play Game");
        System.out.println("b. Instructions");
        System.out.println("c. Credits");
        System.out.println("d. High Score");
        System.out.println("e. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void initializeMaze() {
        for (int i = 0; i < MAZE.length; i++) {
            for (int j = 0; j < MAZE[i].length; j++) {
                if (MAZE[i][j] == 'P') {
                    playerX = j; // Save player's starting X coordinate
                    playerY = i; // Save player's starting Y coordinate
                }
            }
        }
        stepsTaken = 0; // Reset stepsTaken to zero for a new game
    }

    private static void printMaze() {
        System.out.println("Time left: " + ((endTime - System.currentTimeMillis()) / 1000) + " seconds");
        for (int i = 0; i < MAZE.length; i++) {
            for (int j = 0; j < MAZE[i].length; j++) {
                System.out.print(MAZE[i][j] + " ");
            }
            System.out.println();
        }
    }

    private static boolean isValidMove(int newX, int newY) {
        
    	// Check if the new coordinates are within the maze boundaries and not a wall ('#')
        return newX >= 0 && newX < MAZE[0].length && newY >= 0 && newY < MAZE.length && MAZE[newY][newX] != '#';
    }

    private static void movePlayer(char direction) {
        int newX = playerX;
        int newY = playerY;

        // Update the new coordinates based on the chosen direction
        switch (direction) {
            case 'W':
            case 'w':
                newY--;
                break;
            case 'A':
            case 'a':
                newX--;
                break;
            case 'S':
            case 's':
                newY++;
                break;
            case 'D':
            case 'd':
                newX++;
                break;
        }

        if (isValidMove(newX, newY)) {
            MAZE[playerY][playerX] = '.'; // Set the previous position to an open path ('.')
            playerX = newX; // Update player's X coordinate
            playerY = newY; // Update player's Y coordinate
            stepsTaken++;
            if (MAZE[playerY][playerX] == 'E') {
                System.out.println("Congratulations! You've reached the exit!");
                updateScore(); // Update the score and high score
                startNewGame(); // Ask if the player wants to start a new game
            } else {
                MAZE[playerY][playerX] = 'P'; // Set the current position as the new player position
            }
        } else {
            System.out.println("Invalid move. Try again.");
        }
    }

    private static void hasPlayerWon() {
        // Check if the player has reached the exit
        if (MAZE[playerY][playerX] == 'E') {
            System.out.println("Congratulations! You've reached the exit!");
            updateScore(); // Update the score and high score
            startNewGame(); // Ask if the player wants to start a new game
        }
    }

    private static void updateScore() {
        // Deduct 2 points for each valid move from the maximum possible score (100)
        int score = 100 - (stepsTaken * 2);
        if (score > highScore) {
            highScore = score; // Update the high score if the current score is higher
        }
        System.out.println("Score: " + score);
        System.out.println("High Score: " + highScore);
    }

    private static void startNewGame() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Do you want to play again? (Y/N): ");
        char choice = scanner.next().charAt(0);
        scanner.nextLine(); // Consume the newline character after reading the choice

        if (choice == 'Y' || choice == 'y') {
            MAZE = new char[][] {
                {'#', '#', '#', '#', '#', '#', '#'},
                {'#', 'P', '.', '.', '.', '.', '#'},
                {'#', '#', '#', '#', '.', '#', '#'},
                {'#', '.', '.', '.', '.', '.', '#'},
                {'#', '#', '#', '.', '#', '#', '#'},
                {'#', '.', '.', '.', '.', 'E', '#'},
                {'#', '#', '#', '#', '#', '#', '#'}
            };
            stepsTaken = 0; // Reset stepsTaken for the new game
            initializeMaze(); // Find the player's starting position for the new game
            startTime = System.currentTimeMillis();
            endTime = startTime + 60000; // 60 seconds (in milliseconds)
            System.out.println("You have 60 seconds to reach the exit. Good luck!");
        } else {
            System.out.println("Thank you for playing! Goodbye!");
            exitGame(); // Exit the game
            scanner.close();
        }
    }

    private static void showInstructions() {
        System.out.println("\nInstructions:");
        System.out.println("1. The maze will be represented by a 2D grid with walls (#), open paths (.), your starting position (P), and the exit point (E).");
        System.out.println("2. Use W/A/S/D keys to move up, left, down, or right respectively.");
        System.out.println("3. Avoid walls (#) and navigate through open paths to reach the exit (E).");
        System.out.println("4. The game ends only when you reach the exit.");
    }

    private static void showCredits() {
        System.out.println("\nGame developed by [Your Name]");
        System.out.println("Version: 1.0");
    }

    private static void showHighScore() {
        System.out.println("\nHigh Score: " + highScore);
    }

    private static void exitGame() {
        System.out.println("Thank you for playing! Goodbye!");
        System.exit(0); // Terminate the program
    }

    private static void playGame() {
        Scanner scanner = new Scanner(System.in);
        char move;
        boolean gameRunning = true;
        startTime = System.currentTimeMillis();
        endTime = startTime + 60000; // 60 seconds (in milliseconds)

        System.out.println("You have 60 seconds to reach the exit. Good luck!");

        Thread timerThread = new Thread(new Runnable() {
            public void run() {
                while (System.currentTimeMillis() < endTime ) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                boolean gameRunning = false; // Stop the game when time is up
            }
        });

        timerThread.start();

        while (gameRunning) {
            long timeLeft = ((endTime - System.currentTimeMillis()) / 1000);

            if (timeLeft >= 0) {
                System.out.println("\nTime left: " + timeLeft + " seconds");
            } else {
                gameRunning = false;
                break;
            }

            System.out.println("Steps Taken: " + stepsTaken);
            printMaze();
            System.out.print("Enter your move (W/A/S/D): ");
            move = scanner.next().charAt(0);
            scanner.nextLine(); // Consume the newline character after reading the move
            movePlayer(move);

            // Check for a win after each move
            if (MAZE[playerY][playerX] == 'E') {
                System.out.println("Congratulations! You've reached the exit!");
                updateScore();
                gameRunning = false;
                break;
            }
        }

        // Stop the timer thread and wait for it to finish
        try {
            timerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (!gameRunning) {
            System.out.println("\nTime's up! Game Over!");
            updateScore();
            startNewGame(); // Ask if the player wants to start a new game
            scanner.close();
        }
    }
}
